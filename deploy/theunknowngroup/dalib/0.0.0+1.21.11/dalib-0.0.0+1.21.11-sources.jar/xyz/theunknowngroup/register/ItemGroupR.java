package xyz.theunknowngroup.register;

import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ItemGroupR {
    private final String modId;
    private final String name;
    private Supplier<class_1799> icon;
    private class_2561 title;
    private final List<Consumer<class_1761.class_7704>> entries1 = new ArrayList<>();
    private class_5321<class_1761> after;
    public ItemGroupR(String modId, String name) {
        this.modId = modId;
        this.name = name;
    }
    public static ItemGroupR builder(String modId, String name) {
        return new ItemGroupR(modId, name);
    }
    public ItemGroupR icon(Supplier<class_1799> icon) {
        this.icon = icon;
        return this;
    }
    public ItemGroupR title(class_2561 title) {
        this.title = title;
        return this;
    }
    public ItemGroupR entries(Consumer<class_1761.class_7704> entries) {
        this.entries1.add(entries);
        return this;
    }
    public ItemGroupR after(class_5321<class_1761> other) {
        this.after = other;
        return this;
    }
    public class_1761 build() {
        class_5321<class_1761> key = class_5321.method_29179(
                class_7924.field_44688, class_2960.method_60655(modId, name)
        );
        class_1761.class_7913 fabricBuilder = FabricItemGroup.builder()
                .method_47321(title)
                .method_47320(icon)
                .method_47317((_, out) -> entries1.forEach(p -> p.accept(out)));

        return class_2378.method_39197(class_7923.field_44687, key, fabricBuilder.method_47324());
    }
}
