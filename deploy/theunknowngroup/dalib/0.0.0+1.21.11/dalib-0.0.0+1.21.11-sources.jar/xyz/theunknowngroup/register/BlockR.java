package xyz.theunknowngroup.register;

import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class BlockR {
    public static <T extends class_2248> T registerBlock(String modId, String name, Function<class_4970.class_2251, T> fac, class_4970.class_2251 block, class_1792.class_1793 item) {
        class_5321<class_2248> key1 = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(modId, name));
        class_5321<class_1792> key2 = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(modId, name));

        T blocks = fac.apply(block.method_63500(key1));

        registerBlockItem(key2, blocks, item);
        return class_2378.method_39197(class_7923.field_41175, key1, blocks);
    }
    public static class_1747 registerBlockItem(class_5321<class_1792> key2, class_2248 blocks, class_1792.class_1793 item) {
        class_1747 blockItem = new class_1747(blocks, item.method_63686(key2));
        return class_2378.method_39197(class_7923.field_41178, key2, blockItem);
    }
}
