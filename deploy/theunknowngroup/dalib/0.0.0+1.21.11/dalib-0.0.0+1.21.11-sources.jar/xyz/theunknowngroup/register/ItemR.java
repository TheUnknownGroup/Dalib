package xyz.theunknowngroup.register;

import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ItemR {
    public static <T extends class_1792> T registerItem(String modId, String name, Function<class_1792.class_1793, T> fac, class_1792.class_1793 item) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(modId, name));
        T items = fac.apply(item.method_63686(key));
        class_2378.method_39197(class_7923.field_41178, key, items);
        return items;
    }
}
